"""Schema package for the LaTeX Editor Agent."""

from .schema import (
    EditRequest,
    EditResult,
    ParsedDocument,
    Section,
    Zone,
)

__all__ = [
    "Zone",
    "Section",
    "ParsedDocument",
    "EditRequest",
    "EditResult",
]
