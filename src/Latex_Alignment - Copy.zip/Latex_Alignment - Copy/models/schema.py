"""Dataclasses used across the LaTeX Editor Agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Zone:
    """One of the 5 structural zones of a LaTeX paper.

    Names: ``preamble``, ``frontmatter``, ``abstract``, ``body``, ``backmatter``.
    Line indices are **1-based, inclusive** on both ends.
    """

    name: str
    start_line: int
    end_line: int


@dataclass
class Section:
    """A single indexed section (or implicit logical section) of the paper.

    ``parent_id`` / ``children`` are populated by
    :func:`Latex_Alignment.parser.section_indexer._build_tree` after the flat
    list is sorted. They turn the otherwise flat section list into a tree the
    agent can walk for cascade-delete, move, and "list with structure" output.
    """

    id: str
    title: str
    cmd: str
    depth: int
    start_line: int
    end_line: int
    content_hash: str
    citations: list[str] = field(default_factory=list)
    labels: list[str] = field(default_factory=list)
    is_empty: bool = False
    is_implicit: bool = False
    raw_lines: list[str] = field(default_factory=list)
    parent_id: str | None = None
    children: list[str] = field(default_factory=list)


@dataclass
class ParsedDocument:
    """Result of running the parser pipeline on a single ``.tex`` file."""

    file_path: str
    doc_class: str
    doc_style: str
    zones: list[Zone] = field(default_factory=list)
    sections: list[Section] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    bib_keys: list[str] = field(default_factory=list)


@dataclass
class EditRequest:
    """User-facing request to edit a specific section."""

    section_id: str
    instruction: str
    context_sections: list[str] = field(default_factory=list)


@dataclass
class EditResult:
    """Outcome of an edit/generate run; carries everything needed to write back."""

    section_id: str
    original_lines: list[str]
    edited_lines: list[str]
    start_line: int
    end_line: int
    was_empty: bool


__all__ = [
    "Zone",
    "Section",
    "ParsedDocument",
    "EditRequest",
    "EditResult",
]
